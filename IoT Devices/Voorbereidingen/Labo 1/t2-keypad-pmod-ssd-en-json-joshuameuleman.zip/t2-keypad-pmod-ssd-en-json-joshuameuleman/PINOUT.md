# Nucleo-L476RG pinout – templates cheat sheet

This file summarizes the used pins for both provided templates so you can wire quickly during the lab.

Board: NUCLEO-L476RG (LD2 on PA5, USER button PC13). UART2 on Arduino D0/D1.

## Common I/O (both templates)
- USER button: PC13 (`UserButton_Pin`)
- LD1..LD8 helper LEDs:
  - LED1 PC0, LED2 PB3, LED3 PB5, LED4 PB4, LED5 PB10, LED6 PA8, LED7 PC7, LED8 PB6
- Switches and potmeter:
  - POT PA0, SW1 PA1, SW2 PA4, SW3 PB0, SW4 PC1
- UART2 (to ST-Link VCP / Arduino D0-D1):
  - TX2 PA2 (Arduino D1)
  - RX2 PA3 (Arduino D0)

## Polling – Keypad template
- Keypad rows (outputs driven low one-at-a-time):
  - R1 PA12
  - R2 PA11
  - R3 PB12
  - R4 PB11
- Keypad columns (inputs with pull-up):
  - C1 PC8
  - C2 PC6
  - C3 PC5

Signal direction summary:
- Rows R1..R4: Output push-pull, default input when idle (tri-stated) during scan per code.
- Columns C1..C3: Input with pull-up (configure in CubeMX).

## PmodSSD template (2-digit 7-segment)
Segments (active-high):
- A PA10
- B PA9
- C PA6
- D PA7
- E PB9
- F PB8
- G PA5

Digit select:
- CAT PC9 (level selects left vs right digit in code)

Note: Code drives segments high to turn on, and toggles CAT: SET = left, RESET = right, none = all off.

## Quick wiring notes
- UART2 goes to ST-Link’s virtual COM port on the Nucleo via PA2/PA3; you can connect to it from your PC.
- If you bring signals to Arduino headers: D1 = PA2 (TX2), D0 = PA3 (RX2). Other Arduino header mappings depend on the Nucleo pin map; use the STM32 pin names above when wiring.

## References
- See `Polling - Keypad template/Core/Inc/main.h` and `Core/Src/keypad.c`
- See `PmodSSD template/Core/Inc/main.h` and `Core/Src/pmodssd.c`
