#include "stm32l4xx_hal.h"

#if !defined(USART2_DEFINED)
	#define USART2_DEFINED

	// Op dit moment overbodig...
#endif
