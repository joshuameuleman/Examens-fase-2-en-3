using System;
using System.IO.Ports;
using System.Linq;
using System.Windows;

namespace WpfComboBox
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            RefreshPorts();
        }

        private void Refresh_Click(object sender, RoutedEventArgs e) => RefreshPorts();

        private void RefreshPorts()
        {
            var items = SerialPort.GetPortNames().OrderBy(p => p).ToList();
            PortsCombo.ItemsSource = items;
            if (items.Count > 0)
                PortsCombo.SelectedIndex = 0;
        }
    }
}
