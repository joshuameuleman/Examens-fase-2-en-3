using System.Windows;

namespace WpfComboBox
{
    public partial class App : Application { }
}
