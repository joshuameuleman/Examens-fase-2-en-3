using System;
using System.Text.Json;

public record Measurement(string Sensor, double Value, DateTime Timestamp);

class Program
{
    static void Main()
    {
        string json = "{\n  \"sensor\": \"pot\",\n  \"value\": 2.73,\n  \"timestamp\": \"2025-10-11T10:20:30Z\"\n}";

        // Strongly-typed parse
        var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        var m = JsonSerializer.Deserialize<Measurement>(json, options);
        Console.WriteLine($"Typed: {m}");

        // DOM-style parse
        using var doc = JsonDocument.Parse(json);
        var root = doc.RootElement;
        string sensor = root.GetProperty("sensor").GetString()!;
        double value = root.GetProperty("value").GetDouble();
        DateTime ts = root.GetProperty("timestamp").GetDateTime();
        Console.WriteLine($"DOM: sensor={sensor}, value={value}, ts={ts:O}");
    }
}
