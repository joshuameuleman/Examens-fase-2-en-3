# 01 - List COM ports

Minimal console app that prints available COM ports using System.IO.Ports.

Run with .NET SDK installed:

```powershell
# create and run (single-file build)
dotnet new console -n ListComPorts -o . -f net8.0 ; Remove-Item .\Program.cs ; # replace with provided Program.cs
# Or just run the provided Program.cs directly
 dotnet run --project .
```

If you use the inline Program.cs provided here in this folder, you can run:

```powershell
# compile and run quickly without creating csproj (requires .NET 8):
dotnet exec $(dotnet --info | Select-String -Pattern "Base Path" | ForEach-Object { ($_ -split ":\s*")[1].Trim() + "csc.dll" }) Program.cs
```
