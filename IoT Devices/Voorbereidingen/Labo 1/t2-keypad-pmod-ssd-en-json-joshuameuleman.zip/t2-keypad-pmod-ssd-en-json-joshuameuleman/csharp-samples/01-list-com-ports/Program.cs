using System;
using System.IO.Ports;

class Program
{
    static void Main()
    {
        Console.WriteLine("Available COM ports:");
        var ports = SerialPort.GetPortNames();
        Array.Sort(ports, StringComparer.OrdinalIgnoreCase);
        if (ports.Length == 0)
        {
            Console.WriteLine("(none)");
        }
        else
        {
            foreach (var p in ports)
                Console.WriteLine(" - " + p);
        }
    }
}
