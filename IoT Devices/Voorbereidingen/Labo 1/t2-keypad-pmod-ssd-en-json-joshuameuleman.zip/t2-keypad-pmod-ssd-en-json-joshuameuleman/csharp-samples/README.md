# C# samples for the lab

This folder contains minimal, runnable examples for each requested task.

- 01-list-com-ports: Console app listing available COM ports.
- 02-async-serial: Console app receiving UART data asynchronously.
- 03-wpf-combobox: WPF app with a ComboBox dynamically populated with COM ports.
- 04-json-parse: Console app parsing a JSON string to typed object and DOM.

## How to run (PowerShell)

Requires .NET SDK 8.0+ installed.

```powershell
# 1) List COM ports
cd "csharp-samples/01-list-com-ports"
dotnet new console -n ListComPorts -o . -f net8.0 ; Remove-Item .\Program.cs ; # keep provided Program.cs
dotnet run --project .

# 2) Async serial receive
cd "../02-async-serial"
dotnet new console -n AsyncSerial -o . -f net8.0 ; Remove-Item .\Program.cs ; # keep provided Program.cs
dotnet run -- COM5 115200

# 3) WPF ComboBox
cd "../03-wpf-combobox"
dotnet restore ; dotnet run

# 4) JSON parse
cd "../04-json-parse"
dotnet new console -n JsonParse -o . -f net8.0 ; Remove-Item .\Program.cs ; # keep provided Program.cs
dotnet run --project .
```

Tip: On first creation, `dotnet new` generates a csproj. We immediately remove the generated Program.cs to keep the provided one, then `dotnet run` uses the folder project.
