# 02 - Async serial receive

Minimal console app that reads UART data asynchronously using SerialPort.BaseStream.ReadAsync.

Usage (PowerShell):

```powershell
# Create project (one-time) and run
 dotnet new console -n AsyncSerial -o . -f net8.0 ; Remove-Item .\Program.cs ; # replace with provided Program.cs
 dotnet run -- COM3 115200
```

- First argument = COM port (e.g., COM5)
- Second argument = baud rate
- Press Ctrl+C to stop.
