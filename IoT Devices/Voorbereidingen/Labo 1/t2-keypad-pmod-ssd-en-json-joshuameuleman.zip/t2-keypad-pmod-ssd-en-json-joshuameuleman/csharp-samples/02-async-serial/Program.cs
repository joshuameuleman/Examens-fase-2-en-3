using System;
using System.IO.Ports;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        string portName = args.Length > 0 ? args[0] : "COM3"; // adjust
        int baud = args.Length > 1 ? int.Parse(args[1]) : 115200;

        using var sp = new SerialPort(portName, baud)
        {
            Parity = Parity.None,
            DataBits = 8,
            StopBits = StopBits.One,
            Handshake = Handshake.None,
            Encoding = Encoding.ASCII,
            NewLine = "\n"
        };

        sp.Open();
        Console.WriteLine($"Opened {sp.PortName} @ {sp.BaudRate}. Press Ctrl+C to exit.");

        var cts = new CancellationTokenSource();
        Console.CancelKeyPress += (s, e) => { e.Cancel = true; cts.Cancel(); };

        try
        {
            await ReadLoopAsync(sp, cts.Token);
        }
        catch (OperationCanceledException) { }
        finally
        {
            if (sp.IsOpen) sp.Close();
            Console.WriteLine("Closed.");
        }
    }

    static async Task ReadLoopAsync(SerialPort sp, CancellationToken ct)
    {
        var buffer = new byte[256];
        while (!ct.IsCancellationRequested)
        {
            int n = await sp.BaseStream.ReadAsync(buffer.AsMemory(0, buffer.Length), ct);
            if (n > 0)
            {
                var text = Encoding.ASCII.GetString(buffer, 0, n);
                Console.Write(text);
            }
        }
    }
}
